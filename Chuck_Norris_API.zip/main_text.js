async function getChuckData() {
    const url = 'https://api.chucknorris.io/jokes/random';
    const response = await fetch(url);
    const data = await response.json();
    const joketext = data.value;
    const icon_url = data.icon_url;
    //console.log(joketext);

    return [joketext, icon_url];
}

async function displayChuckData(){
    let chuckinfo = await getChuckData();
    console.log(chuckinfo);
    document.getElementById('joke-text').textContent = chuckinfo[0];
    document.getElementById('appico').src = chuckinfo[1]
    $('.preload').fadeOut(1,function(){
        $("#quote").fadeIn(1000);
    })
}
//getChuckData();
// $(function()  {
//     $(".preload").fadeOut(2000, function(){
//         $("#quote").fadeIn(1000);
//     })

// });
displayChuckData();
